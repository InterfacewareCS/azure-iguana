function node.S(ANode)
   return tostring(ANode)
end