Obtained from repository:
https://github.com/bagder/ca-bundle