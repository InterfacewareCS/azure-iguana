<script type="text/javascript" src="/js/jquery-1.11.2/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="/js/jquery-1.11.2/jquery-ui-1.11.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="/browser.js"></script>
